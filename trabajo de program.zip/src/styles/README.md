# Styles

This directory is for configuring the styles of the application.
