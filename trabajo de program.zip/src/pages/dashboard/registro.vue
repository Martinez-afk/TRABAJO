<template>
  <v-container>
    <v-card class="mx-auto" max-width="900" outlined>
      <v-card-title class="headline primary white--text">
        Registro de Estudiante
      </v-card-title>
      <v-card-text>
        <v-form ref="form" v-model="valid" lazy-validation>
          <h2 class="mt-4 mb-2">Datos Personales</h2>
          <v-row>
            <v-col cols="12" md="6">
              <v-text-field
                v-model="student.fullName"
                label="Nombres y Apellidos Completos"
                :rules="nameRules"
                required
                prepend-icon="mdi-account"
              ></v-text-field>
            </v-col>
            <v-col cols="12" md="6">
              <v-text-field
                v-model="student.dob"
                label="Fecha de Nacimiento (DD/MM/AAAA)"
                placeholder="Ej: 01/01/2000"
                :rules="dobRules"
                required
                prepend-icon="mdi-calendar"
                maxlength="10"
                @input="formatDateInput"
              ></v-text-field>
            </v-col>
          </v-row>
          <v-row>
            <v-col cols="12" md="6">
              <v-select
                v-model="student.gender"
                :items="['Masculino', 'Femenino', 'Otro']"
                label="Sexo"
                :rules="[(v) => !!v || 'Sexo es requerido']"
                required
                prepend-icon="mdi-gender-male-female"
              ></v-select>
            </v-col>
            <v-col cols="12" md="6">
              <v-text-field
                v-model="student.documentNumber"
                label="Número de Documento de Identidad"
                :rules="documentRules"
                required
                prepend-icon="mdi-card-account-details"
              ></v-text-field>
            </v-col>
          </v-row>
          <v-text-field
            v-model="student.address"
            label="Dirección de Residencia"
            :rules="addressRules"
            required
            prepend-icon="mdi-home"
          ></v-text-field>

          <h2 class="mt-6 mb-2">Datos del Tutor o Padre de Familia</h2>
          <v-row>
            <v-col cols="12" md="6">
              <v-text-field
                v-model="tutor.fullName"
                label="Nombres y Apellidos Completos del Tutor"
                :rules="nameRules"
                required
                prepend-icon="mdi-account-supervisor"
              ></v-text-field>
            </v-col>
            <v-col cols="12" md="6">
              <v-text-field
                v-model="tutor.relationship"
                label="Parentesco con el Estudiante"
                :rules="relationshipRules"
                required
                prepend-icon="mdi-human-male-female-child"
              ></v-text-field>
            </v-col>
          </v-row>
          <v-row>
            <v-col cols="12" md="6">
              <v-text-field
                v-model="tutor.documentNumber"
                label="Número de Documento de Identidad del Tutor"
                :rules="documentRules"
                required
                prepend-icon="mdi-card-account-details"
              ></v-text-field>
            </v-col>
            <v-col cols="12" md="6">
              <v-text-field
                v-model="tutor.phoneNumber"
                label="Teléfono Celular"
                :rules="phoneRules"
                required
                prepend-icon="mdi-phone"
              ></v-text-field>
            </v-col>
          </v-row>
          <v-text-field
            v-model="tutor.email"
            label="Correo Electrónico"
            :rules="emailRules"
            required
            prepend-icon="mdi-email"
          ></v-text-field>
          <v-text-field
            v-model="tutor.occupation"
            label="Ocupación / Lugar de trabajo (Opcional)"
            prepend-icon="mdi-briefcase"
          ></v-text-field>

          <v-card-actions class="px-0">
            <v-btn color="primary" @click="registerUser" :disabled="!valid">
              Registrar Estudiante
            </v-btn>
            <v-btn color="error" @click="resetForm"> Limpiar Formulario </v-btn>
          </v-card-actions>
        </v-form>
      </v-card-text>
    </v-card>

    <v-divider class="my-8"></v-divider>

    <v-card class="mx-auto" max-width="900" outlined>
      <v-card-title class="headline secondary white--text">
        Estudiantes Registrados
      </v-card-title>
      <v-card-text>
        <v-alert v-if="registeredUsers.length === 0" type="info" prominent text>
          Aún no hay estudiantes registrados.
        </v-alert>
        <v-row v-else>
          <v-col
            v-for="(user, index) in registeredUsers"
            :key="index"
            cols="12"
            md="6"
            lg="4"
          >
            <v-card class="user-card" outlined elevation="3">
              <v-card-title class="pb-0 pt-3">
                <v-icon left>mdi-account-circle</v-icon>
                <span class="text-h6 primary--text">{{ user.student.fullName }}</span>
              </v-card-title>

              <v-card-subtitle class="pt-0 pb-0">
                <v-icon small left>mdi-calendar</v-icon>Fecha Nac.:
                {{ user.student.dob }}
              </v-card-subtitle>
              <v-card-subtitle class="pt-0 pb-0">
                <v-icon small left>mdi-card-account-details</v-icon>Doc. Id.:
                {{ user.student.documentNumber }}
              </v-card-subtitle>
              <v-card-subtitle class="pt-0 pb-2">
                <v-icon small left>mdi-gender-male-female</v-icon>Sexo:
                {{ user.student.gender }}
              </v-card-subtitle>

              <v-expansion-panels flat>
                <v-expansion-panel>
                  <v-expansion-panel-header class="py-2">
                    <span class="font-weight-medium">Ver más detalles</span>
                    <template v-slot:actions>
                      <v-icon color="primary">mdi-chevron-down</v-icon>
                    </template>
                  </v-expansion-panel-header>
                  <v-expansion-panel-content>
                    <v-card-text class="pt-0 pb-2">
                      <p class="mb-1">
                        <v-icon small left>mdi-home</v-icon
                        ><strong>Dirección:</strong> {{ user.student.address }}
                      </p>
                    </v-card-text>

                    <v-divider class="my-2"></v-divider>

                    <v-card-text class="pt-0 pb-0">
                      <p class="mb-1">
                        <v-icon small left>mdi-account-supervisor</v-icon
                        ><strong>Tutor:</strong> {{ user.tutor.fullName }} ({{
                          user.tutor.relationship
                        }})
                      </p>
                      <p class="mb-1">
                        <v-icon small left>mdi-card-account-details</v-icon
                        ><strong>Doc. Tutor:</strong>
                        {{ user.tutor.documentNumber }}
                      </p>
                      <p class="mb-1">
                        <v-icon small left>mdi-phone</v-icon
                        ><strong>Tel. Tutor:</strong>
                        {{ user.tutor.phoneNumber }}
                      </p>
                      <p class="mb-1">
                        <v-icon small left>mdi-email</v-icon
                        ><strong>Email Tutor:</strong> {{ user.tutor.email }}
                      </p>
                      <p v-if="user.tutor.occupation" class="mb-0">
                        <v-icon small left>mdi-briefcase</v-icon
                        ><strong>Ocupación Tutor:</strong>
                        {{ user.tutor.occupation }}
                      </p>
                    </v-card-text>
                  </v-expansion-panel-content>
                </v-expansion-panel>
              </v-expansion-panels>

              <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn
                  text
                  color="secondary"
                  small
                  @click="openEditDialog(user, index)"
                >
                  <v-icon left small>mdi-pencil</v-icon>
                  Editar
                </v-btn>
              </v-card-actions>
            </v-card>
          </v-col>
        </v-row>
      </v-card-text>
    </v-card>

    <!-- Diálogo de Edición -->
    <v-dialog v-model="editDialog" max-width="700px">
      <v-card>
        <v-card-title class="headline primary white--text">
          Editar Estudiante
          <v-spacer></v-spacer>
          <v-btn icon dark @click="editDialog = false">
            <v-icon>mdi-close</v-icon>
          </v-btn>
        </v-card-title>
        <v-card-text class="py-4">
          <v-form ref="editForm" v-model="editValid" lazy-validation>
            <h3 class="mt-2 mb-2">Datos Personales</h3>
            <v-text-field
              v-model="editedStudent.fullName"
              label="Nombres y Apellidos Completos"
              :rules="nameRules"
              required
              prepend-icon="mdi-account"
            ></v-text-field>
            <v-text-field
              v-model="editedStudent.dob"
              label="Fecha de Nacimiento (DD/MM/AAAA)"
              placeholder="Ej: 01/01/2000"
              :rules="dobRules"
              required
              prepend-icon="mdi-calendar"
              maxlength="10"
              @input="formatEditDateInput"
            ></v-text-field>
            <v-select
              v-model="editedStudent.gender"
              :items="['Masculino', 'Femenino', 'Otro']"
              label="Sexo"
              :rules="[(v) => !!v || 'Sexo es requerido']"
              required
              prepend-icon="mdi-gender-male-female"
            ></v-select>
            <v-text-field
              v-model="editedStudent.documentNumber"
              label="Número de Documento de Identidad"
              :rules="documentRules"
              required
              prepend-icon="mdi-card-account-details"
            ></v-text-field>
            <v-text-field
              v-model="editedStudent.address"
              label="Dirección de Residencia"
              :rules="addressRules"
              required
              prepend-icon="mdi-home"
            ></v-text-field>

            <h3 class="mt-4 mb-2">Datos del Tutor o Padre de Familia</h3>
            <v-text-field
              v-model="editedTutor.fullName"
              label="Nombres y Apellidos Completos del Tutor"
              :rules="nameRules"
              required
              prepend-icon="mdi-account-supervisor"
            ></v-text-field>
            <v-text-field
              v-model="editedTutor.relationship"
              label="Parentesco con el Estudiante"
              :rules="relationshipRules"
              required
              prepend-icon="mdi-human-male-female-child"
            ></v-text-field>
            <v-text-field
              v-model="editedTutor.documentNumber"
              label="Número de Documento de Identidad del Tutor"
              :rules="documentRules"
              required
              prepend-icon="mdi-card-account-details"
            ></v-text-field>
            <v-text-field
              v-model="editedTutor.phoneNumber"
              label="Teléfono Celular"
              :rules="phoneRules"
              required
              prepend-icon="mdi-phone"
            ></v-text-field>
            <v-text-field
              v-model="editedTutor.email"
              label="Correo Electrónico"
              :rules="emailRules"
              required
              prepend-icon="mdi-email"
            ></v-text-field>
            <v-text-field
              v-model="editedTutor.occupation"
              label="Ocupación / Lugar de trabajo (Opcional)"
              prepend-icon="mdi-briefcase"
            ></v-text-field>
          </v-form>
        </v-card-text>
        <v-card-actions class="pt-0">
          <v-spacer></v-spacer>
          <v-btn color="error" text @click="editDialog = false">
            Cancelar
          </v-btn>
          <v-btn color="primary" @click="saveEditedUser" :disabled="!editValid">
            Guardar Cambios
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-container>
</template>

<script>
export default {
  data() {
    return {
      valid: true,
      editValid: true, // Para la validación del formulario de edición
      student: {
        fullName: '',
        dob: '',
        gender: null,
        documentNumber: '',
        address: '',
      },
      tutor: {
        fullName: '',
        relationship: '',
        documentNumber: '',
        phoneNumber: '',
        email: '',
        occupation: '',
      },
      registeredUsers: [],

      // Variables para el diálogo de edición
      editDialog: false,
      editedIndex: -1, // Índice del usuario que se está editando
      editedStudent: {
        fullName: '',
        dob: '',
        gender: null,
        documentNumber: '',
        address: '',
      },
      editedTutor: {
        fullName: '',
        relationship: '',
        documentNumber: '',
        phoneNumber: '',
        email: '',
        occupation: '',
      },

      // Reglas de validación (iguales para ambos formularios)
      nameRules: [(v) => !!v || 'Campo requerido', (v) => (v && v.length >= 3) || 'Mínimo 3 caracteres'],
      dobRules: [
        (v) => !!v || 'Fecha de nacimiento es requerida',
        (v) => /^\d{2}\/\d{2}\/\d{4}$/.test(v) || 'Formato de fecha inválido (DD/MM/AAAA)',
        (v) => {
          if (!v || !/^\d{2}\/\d{2}\/\d{4}$/.test(v)) return true;
          const parts = v.split('/');
          const day = parseInt(parts[0], 10);
          const month = parseInt(parts[1], 10);
          const year = parseInt(parts[2], 10);
          const date = new Date(year, month - 1, day);
          return date.getFullYear() === year &&
                 date.getMonth() === month - 1 &&
                 date.getDate() === day || 'Fecha inválida';
        }
      ],
      addressRules: [(v) => !!v || 'Dirección es requerida'],
      documentRules: [(v) => !!v || 'Número de documento es requerido', (v) => /^\d+$/.test(v) || 'Solo números'],
      relationshipRules: [(v) => !!v || 'Parentesco es requerido'],
      phoneRules: [(v) => !!v || 'Teléfono es requerido', (v) => /^\d{10}$/.test(v) || 'Teléfono debe tener 10 dígitos'],
      emailRules: [(v) => !!v || 'E-mail es requerido', (v) => /.+@.+\..+/.test(v) || 'E-mail debe ser válido'],
    };
  },
  methods: {
    formatDateInput(event) {
      let value = event.target.value.replace(/\D/g, '');
      let formattedValue = '';

      if (value.length > 0) {
        if (value.length <= 2) {
          formattedValue = value;
        } else if (value.length <= 4) {
          formattedValue = `${value.slice(0, 2)}/${value.slice(2)}`;
        } else {
          formattedValue = `${value.slice(0, 2)}/${value.slice(2, 4)}/${value.slice(4, 8)}`;
        }
      }
      this.$nextTick(() => {
        this.student.dob = formattedValue;
      });
    },
    // Método para formatear la fecha en el diálogo de edición
    formatEditDateInput(event) {
      let value = event.target.value.replace(/\D/g, '');
      let formattedValue = '';

      if (value.length > 0) {
        if (value.length <= 2) {
          formattedValue = value;
        } else if (value.length <= 4) {
          formattedValue = `${value.slice(0, 2)}/${value.slice(2)}`;
        } else {
          formattedValue = `${value.slice(0, 2)}/${value.slice(2, 4)}/${value.slice(4, 8)}`;
        }
      }
      this.$nextTick(() => {
        this.editedStudent.dob = formattedValue;
      });
    },
    async registerUser() {
      if (this.$refs.form.validate()) {
        const newUser = {
          student: { ...this.student },
          tutor: { ...this.tutor },
        };
        this.registeredUsers.push(newUser);
        this.resetForm();
        alert('Estudiante registrado exitosamente!');
      }
    },
    resetForm() {
      this.$refs.form.reset();
      this.student = {
        fullName: '',
        dob: '',
        gender: null,
        documentNumber: '',
        address: '',
      };
      this.tutor = {
        fullName: '',
        relationship: '',
        documentNumber: '',
        phoneNumber: '',
        email: '',
        occupation: '',
      };
      this.$refs.form.resetValidation();
    },
    openEditDialog(user, index) {
      this.editedIndex = index;
      // Clonar los objetos para evitar mutar el original directamente
      this.editedStudent = { ...user.student };
      this.editedTutor = { ...user.tutor };
      this.editDialog = true;
      // Asegurarse de que el formulario de edición se renderice antes de validar
      this.$nextTick(() => {
        if (this.$refs.editForm) {
          this.$refs.editForm.resetValidation();
        }
      });
    },
    saveEditedUser() {
      if (this.$refs.editForm.validate()) {
        if (this.editedIndex > -1) {
          Object.assign(this.registeredUsers[this.editedIndex].student, this.editedStudent);
          Object.assign(this.registeredUsers[this.editedIndex].tutor, this.editedTutor);
        }
        this.editDialog = false;
        alert('Estudiante actualizado exitosamente!');
      }
    },
  },
};
</script>

<style scoped>
.headline {
  font-weight: bold;
}
.user-card {
  margin-bottom: 20px;
}
.text-h6 {
  font-weight: 500;
}
.v-card-subtitle {
  font-size: 0.85rem;
  color: rgba(0, 0, 0, 0.6);
  display: flex;
  align-items: center;
  padding-bottom: 4px; /* Ajuste para el espaciado entre subtítulos */
}
.v-card-subtitle .v-icon {
  margin-right: 6px; /* Espacio entre icono y texto */
  font-size: 18px; /* Tamaño del icono en subtítulos */
}
.v-card-text p {
  line-height: 1.4;
  font-size: 0.9rem;
  display: flex;
  align-items: flex-start; /* Alinea íconos con la primera línea de texto */
  margin-bottom: 6px; /* Espacio entre párrafos */
}
.v-card-text p .v-icon {
  margin-right: 8px;
  font-size: 18px;
  flex-shrink: 0; /* Evita que el ícono se encoja */
}
.v-card-text strong {
  color: rgba(0, 0, 0, 0.87);
}
.v-expansion-panel-header {
  min-height: 48px !important; /* Ajuste para el tamaño del encabezado del panel */
  padding: 8px 16px;
}
.v-expansion-panel-header span {
  font-size: 0.9rem;
}
</style>